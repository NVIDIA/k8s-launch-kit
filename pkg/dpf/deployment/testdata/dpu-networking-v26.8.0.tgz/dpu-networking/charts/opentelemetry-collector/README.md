# opentelemetry-collector

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.1.0](https://img.shields.io/badge/AppVersion-0.1.0-informational?style=flat-square)

OpenTelemetry Collector for DPU nodes

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.repository | string | `"otel/opentelemetry-collector-contrib"` |  |
| image.tag | string | `"0.146.1@sha256:f6e429c1052ab50f85a7afa5f7e32f25931697751622b0e1f453d10f79a1df3c"` |  |
| imagePullSecrets | list | `[]` |  |
| logging.endpoint | string | `""` | endpoint where the DPU cluster collector sends logs to the management cluster. This MUST be set via DPFOperatorConfig.spec.monitoring.openTelemetryCollector.logging.endpoint. Example: "http://10.0.110.1:30050" (management cluster node IP with NodePort). |
| metrics.endpoint | string | `""` | endpoint where the DPU cluster collector sends metrics to the management cluster. This MUST be set via DPFOperatorConfig.spec.monitoring.openTelemetryCollector.metrics.endpoint. Example: "http://10.0.110.1:30050" (management cluster node IP with NodePort). |
| resources.limits.cpu | string | `"200m"` |  |
| resources.limits.memory | string | `"512Mi"` |  |
| resources.requests.cpu | string | `"100m"` |  |
| resources.requests.memory | string | `"256Mi"` |  |
| serviceDaemonSet.labels | object | `{}` |  |

