# multus

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.1.0](https://img.shields.io/badge/AppVersion-0.1.0-informational?style=flat-square)

A Helm chart for Kubernetes

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| cniBinDir | string | `"/opt/cni/bin"` |  |
| cniConfDir | string | `"/etc/cni/net.d"` |  |
| imagePullSecrets | list | `[]` |  |
| kubeMultusDs.image.repository | string | `"ghcr.io/k8snetworkplumbingwg/multus-cni"` |  |
| kubeMultusDs.image.tag | string | `"v3.9.3@sha256:c173235642a10055db53bc43898fc1058cc6b97178fc3472ce4dafdd6d940d0b"` |  |
| kubeMultusDs.installMultusBinary.containerSecurityContext.privileged | bool | `true` |  |
| kubeMultusDs.installMultusBinary.resources.requests.cpu | string | `"10m"` |  |
| kubeMultusDs.installMultusBinary.resources.requests.memory | string | `"15Mi"` |  |
| kubeMultusDs.kubeMultus.containerSecurityContext.privileged | bool | `true` |  |
| kubeMultusDs.kubeMultus.resources.limits.cpu | string | `"100m"` |  |
| kubeMultusDs.kubeMultus.resources.limits.memory | string | `"100Mi"` |  |
| kubeMultusDs.kubeMultus.resources.requests.cpu | string | `"100m"` |  |
| kubeMultusDs.kubeMultus.resources.requests.memory | string | `"100Mi"` |  |
| kubernetesClusterDomain | string | `"cluster.local"` |  |
| mtu | int | `1500` |  |
| multus.serviceAccount.annotations | object | `{}` |  |
| multusDaemonConfig.daemonConfigJson | string | `"{\n  \"name\": \"multus-cni-network\",\n  \"type\": \"multus\",\n  \"capabilities\": {\n    \"portMappings\": true\n  },\n  \"delegates\": [\n    {\n      \"cniVersion\": \"0.3.1\",\n      \"name\": \"default-cni-network\",\n      \"plugins\": [\n        {\n          \"type\": \"flannel\",\n          \"name\": \"flannel.1\",\n            \"delegate\": {\n              \"isDefaultGateway\": true,\n              \"hairpinMode\": true\n            }\n          },\n          {\n            \"type\": \"portmap\",\n            \"capabilities\": {\n              \"portMappings\": true\n            }\n          }\n      ]\n    }\n  ],\n  \"kubeconfig\": \"/etc/cni/net.d/multus.d/multus.kubeconfig\"\n}"` |  |

