#!/bin/bash
# Launch tower-tap from the JSON process config the chart mounts at
# /config/tap.json. The binary path is in that file (wrapper-only); every
# other knob is passed to tower-tap as -config. No TAP_* environment.
set -euo pipefail

CFG="${1:-/config/tap.json}"

if [[ ! -f "$CFG" ]]; then
  echo "tower-tap: config $CFG missing; sleeping (Envoy ext_proc failure_mode_allow)"
  exec sleep infinity
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "tower-tap: python3 required to read $CFG; sleeping"
  exec sleep infinity
fi

BIN=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("binary") or "/opt/doca-tower/tower-tap")' "$CFG")
OUT=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("out") or "/var/tmp/tower-tap/exchanges.jsonl")' "$CFG")
mkdir -p "$(dirname "$OUT")"

if [[ ! -x "$BIN" ]]; then
  echo "tower-tap: $BIN not executable; sleeping (Envoy ext_proc failure_mode_allow)"
  exec sleep infinity
fi

mapfile -t extra < <(python3 -c 'import json,sys
for a in json.load(open(sys.argv[1])).get("extra_args") or []:
    print(a)
' "$CFG")

echo "tower-tap: exec $BIN -config $CFG ${extra[*]}"
exec "$BIN" -config "$CFG" ${extra[@]+"${extra[@]}"}
