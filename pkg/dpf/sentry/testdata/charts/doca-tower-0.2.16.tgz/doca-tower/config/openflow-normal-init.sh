#!/bin/bash
set -euo pipefail

BRIDGE="${BRIDGE:-br-envoy}"
COOKIE=0xe11

for _ in $(seq 1 60); do
  ovs-vsctl --timeout 5 br-exists "${BRIDGE}" && break
  sleep 1
done
ovs-vsctl --timeout 5 br-exists "${BRIDGE}"

# Remove policy-controller state left by an earlier deployment, then restore
# ordinary MAC-learning bridge behavior.
ovs-ofctl -O OpenFlow13 --timeout=5 del-flows \
  "${BRIDGE}" "cookie=${COOKIE}/-1"
ovs-vsctl --timeout 5 set-fail-mode "${BRIDGE}" standalone
ovs-ofctl -O OpenFlow13 --timeout=5 add-flow \
  "${BRIDGE}" "cookie=${COOKIE},table=0,priority=0,actions=NORMAL"
