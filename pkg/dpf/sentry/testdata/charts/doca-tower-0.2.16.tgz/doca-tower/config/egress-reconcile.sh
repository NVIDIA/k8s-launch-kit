#!/bin/bash
set -euo pipefail

BRIDGE="${BRIDGE:-br-envoy}"
PATCH_DPF_ID="${PATCH_DPF_ID:?PATCH_DPF_ID is required}"
COOKIE=0x544f5745524e4154
ARP_COOKIE=0x544f574552415250
STATE_FILE=/run/doca-tower-egress.flows
DHCP_PID_FILE=/run/dhclient.pid
DHCP_LEASE_FILE=/var/lib/dhcp/dhclient.leases

host_exec() {
  nsenter --net=/proc/1/ns/net -- chroot /host "$@"
}

ovs-vsctl --timeout 15 br-exists "${BRIDGE}"

patch_ports=()
while read -r port; do
  [[ -n "${port}" ]] || continue
  if [[ "$(ovs-vsctl --timeout 15 port-to-br "${port}")" == "${BRIDGE}" ]]; then
    patch_ports+=("${port}")
  fi
done < <(
  ovs-vsctl --timeout 15 --bare --columns=name \
    find Interface "external_ids:dpf-id=${PATCH_DPF_ID}"
)
[[ "${#patch_ports[@]}" -eq 1 ]]
patch_name="${patch_ports[0]}"
[[ "$(ovs-vsctl --timeout 15 port-to-br "${patch_name}")" == "${BRIDGE}" ]]

tower_ports=()
while read -r port; do
  [[ -n "${port}" ]] || continue
  dpf_id="$(
    ovs-vsctl --timeout 15 --if-exists \
      get Interface "${port}" external_ids:dpf-id 2>/dev/null || true
  )"
  dpf_id="${dpf_id//\"/}"
  if [[ "${dpf_id}" == */net2 ]] &&
     [[ "$(ovs-vsctl --timeout 15 port-to-br "${port}")" == "${BRIDGE}" ]]; then
    tower_ports+=("${port}")
  fi
done < <(ovs-vsctl --timeout 15 --bare --columns=name list Interface)
[[ "${#tower_ports[@]}" -eq 1 ]]
tower_name="${tower_ports[0]}"

tower_iface="$(
  ovs-vsctl --timeout 15 get Port "${tower_name}" external_ids:contIface
)"
tower_iface="${tower_iface//\"/}"
[[ "${tower_iface}" == "net2" ]]
ip link show dev "${tower_iface}" >/dev/null

sf_port="$(
  host_exec /sbin/mlnx-sf --action show -j |
    python3 -c '
import json
import sys

matches = [
    name
    for name, port in json.load(sys.stdin).items()
    if port.get("netdev") == sys.argv[1]
]
if len(matches) == 1:
    print(matches[0])
' "${tower_name}"
)"
[[ -n "${sf_port}" ]]

mlxdevm="$(
  host_exec /bin/sh -c '
if command -v mlxdevm >/dev/null 2>&1; then
  command -v mlxdevm
elif [ -x /opt/mellanox/iproute2/sbin/mlxdevm ]; then
  printf "%s\n" /opt/mellanox/iproute2/sbin/mlxdevm
fi
'
)"
[[ -n "${mlxdevm}" ]]

p0_mac="$(cat /sys/class/net/p0/address)"
tower_mac="$(
  ovs-vsctl --timeout 15 get Interface "${tower_name}" external_ids:iface-mac
)"
tower_mac="${tower_mac//\"/}"
[[ -n "${p0_mac}" && -n "${tower_mac}" ]]

set_tower_mac() {
  local current_mac target_mac=$1
  current_mac="$(
    ip -o link show dev "${tower_iface}" |
      awk '{
        for (i = 1; i <= NF; i++) {
          if ($i == "link/ether") {
            print $(i + 1)
            exit
          }
        }
      }'
  )"
  [[ "${current_mac}" == "${target_mac}" ]] && return
  host_exec "${mlxdevm}" port function set "${sf_port}" hw_addr "${target_mac}"
  ip link set "${tower_iface}" down
  ip link set "${tower_iface}" address "${target_mac}"
  ip link set "${tower_iface}" up
}

dhclient_is_running() {
  local pid
  [[ -r "${DHCP_PID_FILE}" ]] || return 1
  read -r pid < "${DHCP_PID_FILE}"
  [[ "${pid}" =~ ^[0-9]+$ ]] || return 1
  [[ -r "/proc/${pid}/cmdline" ]] || return 1
  tr '\0' ' ' < "/proc/${pid}/cmdline" |
    grep -Eq '(^|/)dhclient .*net2( |$)'
}

lease_gateway() {
  [[ -r "${DHCP_LEASE_FILE}" ]] || return 0
  awk '
    /^[[:space:]]*option routers / {
      gateway = $3
      sub(/[;,].*$/, "", gateway)
    }
    END {
      if (gateway != "")
        print gateway
    }
  ' "${DHCP_LEASE_FILE}"
}

tower_port="$(ovs-vsctl --timeout 15 get Interface "${tower_name}" ofport)"
patch_port="$(ovs-vsctl --timeout 15 get Interface "${patch_name}" ofport)"
[[ "${tower_port}" -gt 0 && "${patch_port}" -gt 0 ]]

flows="flow delete cookie=${COOKIE}/0xffffffffffffffff
flow add cookie=${COOKIE},table=0,priority=200,in_port=${tower_port} actions=output:${patch_port}
flow add cookie=${COOKIE},table=0,priority=200,in_port=${patch_port} actions=output:${tower_port}"

if [[ ! -f "${STATE_FILE}" ]] ||
   [[ "$(cat "${STATE_FILE}")" != "${flows}" ]] ||
   ! ovs-ofctl -O OpenFlow13 dump-flows "${BRIDGE}" "cookie=${COOKIE}/-1" |
     grep -q cookie; then
  printf '%s\n' "${flows}" | ovs-ofctl -O OpenFlow13 bundle "${BRIDGE}" -
  printf '%s' "${flows}" > "${STATE_FILE}"
fi

ip link set "${tower_iface}" up
sysctl -w "net.ipv4.conf.${tower_iface}.rp_filter=0" >/dev/null 2>&1 || true
tower_ip="$(
  ip -4 -o addr show dev "${tower_iface}" scope global |
    awk '$4 !~ /^169\.254\./ { print $4; exit }'
)"
if [[ -z "${tower_ip}" ]]; then
  set_tower_mac "${p0_mac}"
  if ! dhclient_is_running; then
    rm -f "${DHCP_PID_FILE}"
    # Use the distribution's standard state paths and lease script. The DPU's
    # dhclient confinement rejects custom paths and scripts mounted from the
    # chart ConfigMap.
    dhclient -4 -1 "${tower_iface}"
  fi
fi

for _ in $(seq 1 30); do
  tower_ip="$(
    ip -4 -o addr show dev "${tower_iface}" scope global |
      awk '$4 !~ /^169\.254\./ { print $4; exit }'
  )"
  tower_gateway="$(lease_gateway)"
  if [[ -z "${tower_gateway}" ]]; then
    tower_gateway="$(
      ip -4 route show default dev "${tower_iface}" |
        awk 'NR == 1 { print $3 }'
    )"
  fi
  [[ -n "${tower_ip}" && -n "${tower_gateway}" ]] && break
  sleep 2
done
[[ -n "${tower_ip}" && -n "${tower_gateway}" ]]
tower_ip="${tower_ip%%/*}"

set_tower_mac "${tower_mac}"
ip route replace default via "${tower_gateway}" dev "${tower_iface}"

arp_flows="flow delete cookie=${ARP_COOKIE}/0xffffffffffffffff
flow add cookie=${ARP_COOKIE},table=0,priority=300,in_port=${patch_port},arp,arp_op=2,arp_spa=${tower_gateway},arp_tpa=${tower_ip} actions=output:${tower_port}"
printf '%s\n' "${arp_flows}" | ovs-ofctl -O OpenFlow13 bundle "${BRIDGE}" -
