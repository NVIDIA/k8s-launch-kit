#!/usr/bin/env bash
# Configure the Envoy netns: VF-island gateway and TPROXY interception.
# Egress networking is configured outside the chart. Does not enable ip_forward.
set -euo pipefail

INGRESS_IF="${INGRESS_IF:-net1}"
INGRESS_IP="${INGRESS_IP:-192.168.100.1}"
INGRESS_PREFIX="${INGRESS_PREFIX:-24}"
INGRESS_CIDR="${INGRESS_CIDR:-192.168.100.0/24}"
HTTP_PORT="${HTTP_PORT:-80}"
HTTPS_PORT="${HTTPS_PORT:-443}"
HTTP_LISTEN="${HTTP_LISTEN:-8080}"
HTTPS_LISTEN="${HTTPS_LISTEN:-8445}"
MARK="${MARK:-1}"
TABLE="${TABLE:-101}"

for _ in $(seq 1 60); do
  ip link show "$INGRESS_IF" >/dev/null 2>&1 && break
  sleep 1
done
ip link show "$INGRESS_IF" >/dev/null

# Namespaced sysctls may be read-only without privileged; TPROXY still works
# with CAP_NET_ADMIN as long as we do not enable forwarding.
sysctl -w net.ipv4.ip_forward=0 >/dev/null 2>&1 || true
sysctl -w net.ipv4.conf.all.rp_filter=0 >/dev/null 2>&1 || true
sysctl -w net.ipv4.conf.default.rp_filter=0 >/dev/null 2>&1 || true
sysctl -w net.ipv4.conf.all.route_localnet=1 >/dev/null 2>&1 || true
sysctl -w "net.ipv4.conf.${INGRESS_IF}.rp_filter=0" >/dev/null 2>&1 || true

ip link set "$INGRESS_IF" up
ip addr replace "${INGRESS_IP}/${INGRESS_PREFIX}" dev "$INGRESS_IF"

ip route replace "$INGRESS_CIDR" dev "$INGRESS_IF"

ip rule show | grep -q "fwmark 0x${MARK} lookup ${TABLE}" \
  || ip rule add fwmark "$MARK" lookup "$TABLE"
ip route show table "$TABLE" | grep -q '^local default' \
  || ip route add local 0.0.0.0/0 dev lo table "$TABLE"

iptables -t mangle -C PREROUTING -s "$INGRESS_CIDR" ! -d "$INGRESS_IP" \
  -p tcp --dport "$HTTP_PORT" -j TPROXY --on-port "$HTTP_LISTEN" --tproxy-mark "$MARK" 2>/dev/null \
|| iptables -t mangle -A PREROUTING -s "$INGRESS_CIDR" ! -d "$INGRESS_IP" \
  -p tcp --dport "$HTTP_PORT" -j TPROXY --on-port "$HTTP_LISTEN" --tproxy-mark "$MARK"

iptables -t mangle -C PREROUTING -s "$INGRESS_CIDR" ! -d "$INGRESS_IP" \
  -p tcp --dport "$HTTPS_PORT" -j TPROXY --on-port "$HTTPS_LISTEN" --tproxy-mark "$MARK" 2>/dev/null \
|| iptables -t mangle -A PREROUTING -s "$INGRESS_CIDR" ! -d "$INGRESS_IP" \
  -p tcp --dport "$HTTPS_PORT" -j TPROXY --on-port "$HTTPS_LISTEN" --tproxy-mark "$MARK"

echo "[ok] ${INGRESS_IF}=${INGRESS_IP}/${INGRESS_PREFIX}"
echo "[ok] TPROXY tcp/${HTTP_PORT}->:${HTTP_LISTEN} tcp/${HTTPS_PORT}->:${HTTPS_LISTEN} from ${INGRESS_CIDR}"
ip addr show "$INGRESS_IF"
ip route
iptables -t mangle -L PREROUTING -n -v
