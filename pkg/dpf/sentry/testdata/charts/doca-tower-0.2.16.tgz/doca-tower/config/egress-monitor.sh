#!/bin/bash
set -uo pipefail

while true; do
  if /config/egress-reconcile.sh; then
    sleep 5
  else
    status=$?
    echo "egress reconciliation failed (exit ${status})" >&2
    sleep 2
  fi
done
