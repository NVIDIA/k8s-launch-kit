{{/*
Expand the name of the chart.
*/}}
{{- define "doca-tower.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "doca-tower.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "doca-tower.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "doca-tower.labels" -}}
helm.sh/chart: {{ include "doca-tower.chart" . }}
{{ include "doca-tower.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "doca-tower.selectorLabels" -}}
app.kubernetes.io/name: {{ include "doca-tower.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
JSON process config for tower-tap (-config /config/tap.json).
binary / extra_args are wrapper-only; the rest map to tower-tap flags.
*/}}
{{- define "doca-tower.dataplaneMode" -}}
{{- $m := default "observe" .Values.dataplane.mode -}}
{{- if and (ne $m "observe") (ne $m "enforce") -}}
{{- fail (printf "dataplane.mode must be observe or enforce (got %s)" $m) -}}
{{- end -}}
{{- $m -}}
{{- end -}}

{{/*
max_message_timeout is three classifier calls. tap.judgeTimeout is a whole
number of seconds, such as 10s.
*/}}
{{- define "doca-tower.maxMessageTimeout" -}}
{{- $t := .Values.tap.judgeTimeout | toString -}}
{{- if hasSuffix "ms" $t -}}
{{- fail "tap.judgeTimeout must be a whole number of seconds, like 10s" -}}
{{- end -}}
{{- if not (hasSuffix "s" $t) -}}
{{- fail "tap.judgeTimeout must be a whole number of seconds, like 10s" -}}
{{- end -}}
{{- printf "%ds" (mul (trimSuffix "s" $t | int) 3) -}}
{{- end -}}

{{/*
ext_proc on both listeners. dataplane.mode observe records and cannot refuse.
enforce buffers the response and allows one override_message_timeout per body.
ext_authz is not changed here.
*/}}
{{- define "doca-tower.extProc" -}}
- name: envoy.filters.http.ext_proc
  typed_config:
    "@type": type.googleapis.com/envoy.extensions.filters.http.ext_proc.v3.ExternalProcessor
{{- if eq (include "doca-tower.dataplaneMode" .) "enforce" }}
    observability_mode: false
    message_timeout: 1s
    max_message_timeout: {{ include "doca-tower.maxMessageTimeout" . }}
{{- else }}
    observability_mode: true
    message_timeout: 0.2s
{{- end }}
    failure_mode_allow: true
    grpc_service:
      envoy_grpc: { cluster_name: tower_tap }
    metadata_options:
      forwarding_namespaces:
        untyped: ["envoy.filters.http.ext_authz"]
    response_attributes: ["response.code_details"]
    processing_mode:
      request_header_mode: SEND
      response_header_mode: SEND
      request_body_mode: STREAMED
{{- if eq (include "doca-tower.dataplaneMode" .) "enforce" }}
      response_body_mode: BUFFERED
{{- else }}
      response_body_mode: STREAMED
{{- end }}
      request_trailer_mode: SKIP
      response_trailer_mode: SKIP
{{- end }}

{{- define "doca-tower.tapConfig" -}}
{
  "binary": {{ .Values.tap.binary | toJson }},
  "socket": {{ .Values.tap.socket | toJson }},
  "out": {{ .Values.tap.out | toJson }},
  "reply": {{ eq (include "doca-tower.dataplaneMode" .) "enforce" }},
  "judge_url": {{ .Values.tap.judgeURL | toJson }},
  "judge_model": {{ .Values.tap.judgeModel | toJson }},
  "judge_timeout": {{ .Values.tap.judgeTimeout | toJson }},
  "max_message_timeout": {{ if eq (include "doca-tower.dataplaneMode" .) "enforce" }}{{ include "doca-tower.maxMessageTimeout" . | toJson }}{{ else }}"0s"{{ end }},
  "bash_rules": {{ .Values.tap.bashRules | toJson }},
  "pack_dir": "/var/run/tower-tap-packs",
  "extra_args": {{ .Values.tap.extraArgs | default list | toJson }}
}
{{- end }}


